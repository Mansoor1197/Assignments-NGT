package user;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.Scanner;
import beans.*;
import dao.IDao;
import validation.Validation;


public class Sorting {
	
	public static void main(String[] args) {
		IDao dao = new IDao();
                Validation validaton=new Validation();
		Scanner sc=new Scanner(System.in);
		
		while (true) {
			
			
			System.out.println("Enter your choice: \n 1.Add Employee \n 2.Sort by empid"
					+ " \n 3.Sort by first name \n 4.Sort by last name\n 5.Sort by salary\n 6.Sort by address\n 7.Sort by dept"
					+ "\n 8.Exit ");
			
			switch (sc.nextInt()) {
			case 1:
				Employee emp=new Employee();
				Department dept=new Department();
				Address add=new Address();
				System.out.println("enter employee id");
				while (true) {
					String employeeid=sc.next();
					if (validation.employeeIdValidation(employeeid)) {
						if(!dao.map.containsKey(employeeid)) {
						emp.setEmployeeID(employeeid);
						break;
						}
						else {
							System.out.println("enter unique employee id");
						}
					}
					else
						System.out.println("Invalid !! Please enter valid employee id");
				}
				System.out.println("enter first name");
				while (true) {
					String firstname=sc.next();
					if (validation.employeeNameValidation(firstname)) {
							emp.setFirstName(firstname);
						break;
					}
					else
						System.out.println("enter name in valid format");
				}
				System.out.println("enter last name");
				while (true) {
					String lastname=sc.next();
					if (validation.employeeNameValidation(lastname)) {
						emp.setLastName(lastname);
						break;
					}
					else
						System.out.println("enter name in valid format");
				}
				System.out.println("employee salary");
				while (true) {
					double salary=sc.nextDouble();
					if (validation.salaryValidation(salary)) {
						emp.setSalary(salary);
						break;
					}
					else
						System.out.println("enter salary between 20000 and 500000");
				}
				System.out.println("enter the date of joining");
				while (true) {
					String doj=sc.next();
					if (validation.dateValidation(doj)) {
						emp.setDateOfJoining(doj);
						break;
					}
					else
						System.out.println("previous dates are not allowed");
				}
				System.out.println("enter department id");
				dept.setDeptId(sc.nextInt());
				System.out.println("enter department name");
				dept.setDeptName(sc.next());
				System.out.println("enter location");
				dept.setLocation(sc.next());
				emp.setDepartment(dept);

				System.out.println("enter address id");
				add.setAddressId(sc.nextInt());
				System.out.println("enter address line");
				add.setAddressLine1(sc.next());
				System.out.println("enter city");
				add.setCity(sc.next());
				System.out.println("enter state");
				add.setState(sc.next());
				emp.setAddress(add);
				dao.map.put(emp.getEmployeeID(), emp);
				System.out.println("employee created"+dao.map);
				break;
			
			case 2:
				Set<Entry<String,Employee>>entrySet1=dao.map.entrySet();
				List<Entry<String,Employee>> list1=new ArrayList<Map.Entry<String,Employee>>(entrySet1);
				Collections.sort(list1, new Comparator<Entry<String,Employee>>() {

					@Override
					public int compare(Entry<String, Employee> o1, Entry<String, Employee> o2) {
						
						return o1.getValue().getEmployeeID().compareTo(o2.getValue().getEmployeeID());
					}
				});
				System.out.println("sorted based on emp id");
				list1.forEach(e->{
					System.out.println("\t"+e.getValue().getEmployeeID()+"\t"+e.getValue().getFirstName());
				});
				 break;
			case 3:
				Set<Entry<String,Employee>>entrySet=dao.map.entrySet();
				List<Entry<String,Employee>> list=new ArrayList<Map.Entry<String,Employee>>(entrySet);
				Collections.sort(list, new Comparator<Entry<String,Employee>>() {

					@Override
					public int compare(Entry<String, Employee> o1, Entry<String, Employee> o2) {
						
						return o1.getValue().getFirstName().compareToIgnoreCase(o2.getValue().getFirstName());
					}
				});
				System.out.println("sorted based on first name");
				list.forEach(e->{
					System.out.println(e.getKey()+"\t"+e.getValue().getFirstName());
				});
				break; 
			
			case 4:
				Set<Entry<String,Employee>>entrySet=dao.map.entrySet();
				List<Entry<String,Employee>> list=new ArrayList<Map.Entry<String,Employee>>(entrySet);
				Collections.sort(list, new Comparator<Entry<String,Employee>>() {

					@Override
					public int compare(Entry<String, Employee> o1, Entry<String, Employee> o2) {
						
						return o1.getValue().getLastName().compareToIgnoreCase(o2.getValue().getLastName());
					}
				});
				System.out.println("sorted based on last name");
				list.forEach(e->{
					System.out.println(e.getKey()+"\t"+e.getValue().getLastName());
				});
				break; 
			
			case 5:
				Set<Entry<String,Employee>>entrySet=dao.map.entrySet();
				List<Entry<String,Employee>> list=new ArrayList<Map.Entry<String,Employee>>(entrySet);
				Collections.sort(list, new Comparator<Entry<String,Employee>>() {

					@Override
					public int compare(Entry<String, Employee> o1, Entry<String, Employee> o2) {
						
						if(o1.getValue().getSalary()<o2.getValue().getSalary())
								return 1;
							else if(o1.getValue().getSalary()>o2.getValue().getSalary())
								return -1;
							else
								return 0;
					}
					
				});
				System.out.println("sorted based on salary");
				list.forEach(e->{
					System.out.println(e.getKey()+"\t"+e.getValue().getFirstName()+"\t"+e.getValue().getSalary());
				});
				break; 
			
			case 6:
				Set<Entry<String,Employee>>entrySet=dao.map.entrySet();
				List<Entry<String,Employee>> list=new ArrayList<Map.Entry<String,Employee>>(entrySet);
				Collections.sort(list, new Comparator<Entry<String,Employee>>() {

					@Override
					public int compare(Entry<String, Employee> o1, Entry<String, Employee> o2) {
						
						return o1.getValue().getAddress().getAddressId().compareTo(o2.getValue().getAddress().getAddressId());
					}
				});
				System.out.println("sorted based on address id");
				list.forEach(e->{
					System.out.println(e.getKey()+"\t"+e.getValue().getAddress());
				});
				break; 
			
			case 7:
				Set<Entry<String,Employee>>entrySet=dao.map.entrySet();
				List<Entry<String,Employee>> list=new ArrayList<Map.Entry<String,Employee>>(entrySet);
				Collections.sort(list, new Comparator<Entry<String,Employee>>() {

					@Override
					public int compare(Entry<String, Employee> o1, Entry<String, Employee> o2) {
						
						return o1.getValue().getDepartment().getDepartmentId().compareTo(o2.getValue().getDepartment().getDepartmentId());
					}
				});
				System.out.println("sorted based on dept id");
				list.forEach(e->{
					System.out.println(e.getKey()+"\t"+e.getValue().getDepartment());
				});
				break; 
			
			case 8:System.out.println("thank you...");
			break;

	    }

       }
	    }
	 
       }
