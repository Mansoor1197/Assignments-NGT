package dao;

import java.util.Map;
import java.util.TreeMap;
import beans.Employee;

         public class IDao {
	            public Map<String,Employee> map;
	            public IDao() {
		        map = new TreeMap<String,Employee>();
	            }
    }
