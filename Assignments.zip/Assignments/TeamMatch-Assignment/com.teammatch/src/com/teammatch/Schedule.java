package com.teammatch;

import java.util.Scanner;


          public class Schedule {
          public static void main(String[] args) {
	         PlayerBO playerbo= new PlayerBO();
	         TeamBO teambo= new TeamBO();
	         MatchBO matchbo= new MatchBO();
	         Scanner sc=new Scanner(System.in);
	
	         System.out.println("Enter the player count: "); 
	         int noOfplayers=sc.nextInt();
	         sc.nextLine();
	         Player[] playerList= new Player[noOfplayers];
	
	        for(int t=0; t<noOfplayers; t++) {
		      System.out.println("Enter player "+(t+1)+" details");
		      playerList[t]=playerbo.createPlayer(sc.nextLine());
	        }
	
	        System.out.println("Enter the Team count:"); 
	        int noOfteams=sc.nextInt();
	        sc.nextLine();
	        Team[] teamList= new Team[noOfteams];
	
	        for(int t=0; t<noOfteams; t++) {
		        System.out.println("Enter team "+(t+1)+" details");
		        teamList[t]=teambo.createTeam(sc.nextLine(),playerList);
	        }

	        System.out.println("Enter the Match count: "); 
	        int noOfmatch=sc.nextInt();
	        sc.nextLine();
	        Match[] matchList= new Match[noOfmatch];
	
	        for(int t=0; t<noOfmatch; t++) {
		         System.out.println("Enter match "+(t+1)+" details");
		         matchList[t]=matchbo.createMatch(sc.nextLine(), teamList);
	        }
		System.out.println("Menu:");
		System.out.println("1) Find Team  \n" + "2) Find All Matches In A Specific Venue");
		System.out.println("enter choice 1 or 2");
                int choice = sc.nextInt();
		switch(choice){
		case 1: 
			System.out.println("Enter match date");
			matchbo.findTeam(sc.next(), matchList);
			break;
		case 2:
			System.out.println("Enter Team name");
			matchbo.findAllMatchesOfTeam(sc.next(), matchList);
			break;
		default:
			System.out.println("Do you want to continue? Yes/No");
			String option = sc.next();
			if(option.equals("Yes")) {
				continue;
			}
			else {
				System.out.println("Exit");
				break;
			}
		}
		
	}
 }
