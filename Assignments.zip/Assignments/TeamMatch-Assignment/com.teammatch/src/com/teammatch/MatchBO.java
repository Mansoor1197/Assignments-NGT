package com.teammatch;

public class MatchBO {
	public Match createMatch(String data, Team[] teamList) {
		String [] info=data.split(",");
		Team team1=null;
                Team team2=null;
		for(Team team : teamList) {
			if(team.getName().equals(info[1]))
				team1= team;
			if(team.getName().equals(info[2]))
				team2= team;
		}
		
		return new Match(info[0], team1, team2, info[3]);
		
	}
	
	public void findTeam(String matchDate, Match[] matchList) {
		for(Match mb : matchList) {
			if( mb.getDate().equals(matchDate) )
					System.out.println(mb.getTeamone().getName()+","+mb.getTeamtwo().getName());
				
		}
	}
	
	public void findAllMatchesOfTeam(String teamName, Match[] matchList) {
		for(Match mb : matchList) {
			if( (mb.getTeamone().getName().equals(teamName)) || (mb.getTeamtwo().getName().equals(teamName)) )
				System.out.println(mb.getDate()+" "+mb.getTeamone().getName()+" "+mb.getTeamtwo().getName()+" "+mb.getVenue());
	        }
	}
}
