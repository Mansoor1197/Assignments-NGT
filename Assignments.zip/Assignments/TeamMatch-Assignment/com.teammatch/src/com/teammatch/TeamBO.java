package com.teammatch;

public class TeamBO {
	public Team createTeam(String data, Player[] playerList) {
		
                String [] teaminfo=data.split(",");
		Player player=null;
		for(Player p : playerList) {
			if(p.getName().equals(teaminfo[1])){
				player= p;
                                break;
                        }
		}
		return new Team(teaminfo[0], player);
	}

}
