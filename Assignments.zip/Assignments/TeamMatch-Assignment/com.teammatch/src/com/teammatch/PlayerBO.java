package com.teammatch;

    public class PlayerBO {

	   public Player createPlayer (String data) {
		String playerinfo[] =data.split(",");
		return new Player(playerinfo[0], playerinfo[1], playerinfo[2]) ;

	    }
}
